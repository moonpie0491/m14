// pages/contact.js

import React from "react";

const Contact = () => {
	return (
		<div>
            <h>*</h>
			<h2>
                Mobile No. : 1234567890 <br/>
				Mail us on: admin@gmail.com <br/>
				Address: Kondhva, Pune.
			</h2>
		</div>
	);
};

export default Contact;
