//pages/about.js

import React from "react";

const About = () => {
	return (
		<div>
			<h1>
            This is 4th Assignment of Advance Web Technology.
            </h1>
		</div>
	);
};

export default About;
