// Filename - App.js

import React from "react";
import Navbar from "./components/Navbar";
import {
	BrowserRouter as Router,
	Routes,
	Route,
} from "react-router-dom";
import Home from "./pages";
import About from "./pages/about";
import Register from "./pages/Register";
import Contact from "./pages/contact";
import Login from "./pages/Login";
import Welcome from './pages/welcome';


function App() {
	return (
		<Router>
			<Navbar />
			<Routes>
				<Route exact path="/" element={<Home />} />
				<Route path="/about" element={<About />} />
				<Route path="/contact" element={<Contact />}/>
				<Route path="/register" element={<Register/>}/>
                <Route path="/login" element={<Login/>}/>
				<Route path="/welcome" element={<Welcome />} />
			</Routes>
		</Router>
	);
}

export default App;
